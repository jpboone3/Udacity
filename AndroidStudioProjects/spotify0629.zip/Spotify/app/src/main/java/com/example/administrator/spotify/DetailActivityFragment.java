package com.example.administrator.spotify;

import android.app.ActionBar;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import kaaes.spotify.webapi.android.SpotifyApi;
import kaaes.spotify.webapi.android.SpotifyService;
import kaaes.spotify.webapi.android.models.Track;
import kaaes.spotify.webapi.android.models.TracksPager;
//import android.support.v7.app.*;

/**
 * A placeholder fragment containing a simple view.
 */
public class DetailActivityFragment extends Fragment{

    private String mAlbum = null;
    ArrayAdapter mArtistadApter = null;
    private ArrayList<StreamerArtist> artists = new ArrayList<StreamerArtist>();


    MediaPlayer mediaPlayer;
    private MediaController mcontroller;
    private Handler handler = new Handler();


    public DetailActivityFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_detail, container, false);
        ArrayList<String> ar = new ArrayList();
        ar.add("No Artist Tracks loaded");


        Bundle extras = getActivity().getIntent().getExtras();

        mAlbum = extras.getString("artist");

        // set the title/subtitle on the action bar
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Top 10 Tracks");
        ((AppCompatActivity) getActivity()).getSupportActionBar().setSubtitle(mAlbum);


        //getActivity().setTitle("Top 10 Tracks\n" + mAlbum);
        //if (mAlbum != null)
        //    Toast.makeText(getActivity(), mAlbum, Toast.LENGTH_LONG).show();

/*
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        if (preferences != null) {

            String name = preferences.getString("pref_artist", null);
            if (name != null)
                artist_name.setText(name);
        }

*/                // instantiate our ArtistAdapter class
        mArtistadApter = new StreamerAdapter(getActivity(), R.layout.list_item_artist, artists);

        ListView lv = (ListView) rootView.findViewById(R.id.listview_artist);
        //lv.requestFocus();

        lv.setAdapter(mArtistadApter);

        //context = lv.getContext();
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                //parent,getItemAtPosition(position);
                StreamerArtist sa = (StreamerArtist) parent.getItemAtPosition(position);
                String text = sa.name;


/*
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(sa.preview_url));
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.setDataAndType(Uri.parse(sa.preview_url), "audio/mpeg4-generic");
                startActivity(intent);



Uri myUri = Uri.parse(sa.song_url);
Intent intent = new Intent(android.content.Intent.ACTION_VIEW);
intent.setDataAndType(myUri, "audio/*");
startActivity(intent);
*/

                try {
                    String url = sa.preview_url;
/*
                    //MediaPlayer mediaPlayer = new MediaPlayer();
                    mediaPlayer = new MediaPlayer();
                    mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    mediaPlayer.setDataSource(url);

                    mediaPlayer.prepare(); // might take long! (for buffering, etc)
                    mediaPlayer.setScreenOnWhilePlaying(true);
                    mediaPlayer.start();
*/

                    mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    //mediaPlayer.setOnBufferingUpdateListener(this);
                    //mediaPlayer.setOnCompletionListener(this);
                    //mediaPlayer.setOnPreparedListener(this);
                    //mediaPlayer.setScreenOnWhilePlaying(true);
                    //mediaPlayer.setOnVideoSizeChangedListener(this);
                    mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    mcontroller = new MediaController(this);


                }
                catch (IOException io){
                }
                catch (IllegalArgumentException ia){
                }




            }
        });




        return rootView;
    }
    @Override
    public void onStart() {
        super.onStart();
        updateTracks();
    }
    protected void updateTracks() {

        //boolean metric = preferences.getBoolean("pref_metric", true);
        DetailActivityFragment.TracklisttaSk task = new DetailActivityFragment.TracklisttaSk();
        //if (metric)
        if (mAlbum != null && mAlbum.length() > 0) {

            //Toast.makeText(getActivity(), "Seaching Spotify", Toast.LENGTH_LONG).show();
            task.execute(mAlbum);
        }

    }

    public class TracklisttaSk extends AsyncTask<String, String, List> {

        static final String myLOGFILTER = "ArtisTlisttaSk";

        //static final String myLOGFILTER = ArtisTlisttaSk.getClass().getSimpleName();
        public TracklisttaSk() {
        }

        //protected String doInBackground(String... args) {}
        //protected String doInBackground(Object[] params) {
        protected List doInBackground(String... params) {

            String mQuery = params[0]; //.trim().replaceAll(" ", "%20");

//Log.d("Spotify params[0]: ", params[0]);
//Log.d("Spotify q: ", q);
            List<StreamerArtist> mSlist = new ArrayList<StreamerArtist>();

            SpotifyApi mApi = new SpotifyApi();
            if (mApi == null)
                return null;
            SpotifyService mService = mApi.getService();
            if (mService == null)
                return null;

            TracksPager mTm = mService.searchTracks(mQuery);
            //List listOfArtists = mTm.tracks;
            List listOfArtists = mTm.tracks.items;

            for (int i = 0; i < listOfArtists.size(); i++) {

                StreamerArtist sa = new StreamerArtist();
                Track a = (Track) listOfArtists.get(i);
                sa.name = a.name;
                sa.id = a.id;
                //sa.popularity = a.popularity.intValue;
                sa.popularity = a.popularity;
                sa.preview_url = a.preview_url;

                // this should work if you have a Spotify account
                //sa.preview_url = (String) a.album.external_urls.get("spotify");


                if (a.album.images != null) {
                    // find the image that is 54 in height
                    String url = null;
                    int mLargest = 0;
                    for (int j = 0; j < a.album.images.size(); j++) {
                        if (a.album.images.get(j).height <= 64)
                            url = a.album.images.get(j).url;

                        // set the song url to the largets image
                        // for the music play
                        if (mLargest < a.album.images.get(j).height) {
                            mLargest = a.album.images.get(j).height;
                            sa.song_url = a.album.images.get(j).url;
                        }
                    }
                    if (url != null) {
                        sa.thumbnail = null;
                        try {
                            URL aURL = new URL(url);
                            URLConnection conn =
                                    conn = aURL.openConnection();
                            conn.connect();

                            InputStream is = conn.getInputStream();
                            BufferedInputStream bis = new BufferedInputStream(is);
                            sa.thumbnail = BitmapFactory.decodeStream(bis);
                            bis.close();
                            is.close();
                        } catch (IOException e) {
                            // TO DO
                            Log.e("ArtistAdapter", "Error getting bitmap", e);
                        }

                    }

                }

                mSlist.add(sa);

            }
            // Need to return the top ten tracks based on popularity
            // First bubble sort popularity in reverse order
            Collections.sort(mSlist);

            // only want to retturn the top 10 tracks
            while (mSlist.size() > 10) {
                mSlist.remove(10);
            }


            return mSlist;
        }

        //@Override
        protected void onPostExecute(List l) {
            mArtistadApter.clear();
            //Log.d("lengthg ", "length: " + s.length);
            if (l == null || l.size() == 0) {
                Toast.makeText(getActivity(), "No artists were found to display.", Toast.LENGTH_LONG).show();
                return;
            }
            //mArtistadApter.addAll(s);
            mArtistadApter.addAll(l);
            super.onPostExecute(l);
        }

    }


}
