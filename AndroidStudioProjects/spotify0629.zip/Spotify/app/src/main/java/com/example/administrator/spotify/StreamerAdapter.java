package com.example.administrator.spotify;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by administrator on 6/26/15.
 */

public class StreamerAdapter extends ArrayAdapter<StreamerArtist> {

    // declaring our ArrayList of artists
    private ArrayList<StreamerArtist> objects = null;
    private final Context context;

    /* here we must override the constructor for ArrayAdapter
    * the only variable we care about now is ArrayList<Artist> objects,
    * because it is the list of objects we want to display.
    */
    public StreamerAdapter(Context context, int textViewResourceId, ArrayList<StreamerArtist> objects) {
        super(context, textViewResourceId, objects);
        this.objects = objects;
        this.context = context;
    }

    /*
     * we are overriding the getView method here - this is what defines how each
     * list artist will look.
     */
    public View getView(int position, View convertView, ViewGroup parent) {

        // assign the view we are converting to a local variable
        View v = convertView;

        // first check to see if the view is null. if so, we have to inflate it.
        // to inflate it basically means to render, or show, the view.
        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.list_item_artist, null);
        }

        /*
         * Recall that the variable position is sent in as an argument to this method.
         * The variable simply refers to the position of the current object in the list. (The ArrayAdapter
         * iterates through the list we sent it)
         *
         * Therefore, i refers to the current Artist object.
         */
        StreamerArtist i = objects.get(position);

        if (i != null) {
//Log.d("ArtistAdapter ", i.name);
            // This is how you obtain a reference to the TextViews.
            // These TextViews are created in the XML files we defined.
            ImageView icon = (ImageView) v.findViewById(R.id.list_item_icon);
            if (icon != null && i.thumbnail != null) {
                icon.setImageBitmap(i.thumbnail);
            }

            TextView name = (TextView) v.findViewById(R.id.list_item_name);

            // check to see if each individual textview is null.
            // if not, assign some text!
            if (name != null) {
                name.setText(i.name);
            }
        }

        // the view must be returned to our
        return v;

    }

}
