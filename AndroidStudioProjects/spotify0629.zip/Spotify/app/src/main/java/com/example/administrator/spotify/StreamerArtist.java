package com.example.administrator.spotify;

import android.graphics.Bitmap;

/**
 * Created by administrator on 6/26/15.
 */
public class StreamerArtist implements Comparable<StreamerArtist>{

    public String id;
    public String name;
    public String preview_url = null;
    public String song_url = null;

    public Bitmap thumbnail = null;
    public int popularity = -1;
    //public Integer popularity;


    public int compareTo(StreamerArtist compareStreamerArtist) {

        //int compareQuantity = ((StreamerArtist) compareFruit).getQuantity();


        //descending order
        return compareStreamerArtist.popularity - this.popularity;

    }

}
