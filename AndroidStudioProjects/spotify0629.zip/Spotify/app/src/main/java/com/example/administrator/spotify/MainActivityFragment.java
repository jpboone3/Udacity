package com.example.administrator.spotify;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import kaaes.spotify.webapi.android.SpotifyService;
import kaaes.spotify.webapi.android.models.Artist;
import kaaes.spotify.webapi.android.models.ArtistsPager;
import kaaes.spotify.webapi.android.*;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment {

    ArrayAdapter mArtistadApter = null;
    private ArrayList<StreamerArtist> artists = new ArrayList<StreamerArtist>();
    EditText artist_name;
    final int MAX_ARTISTS_TO_LIST = 50;

    public MainActivityFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        View rootView = inflater.inflate(R.layout.fragment_main, container, false);
        ArrayList<String> ar = new ArrayList();
        ar.add("No Artist loaded");

        artist_name = (EditText) rootView.findViewById(R.id.artist_name);


        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
        if (preferences != null) {

            String name = preferences.getString("pref_artist", null);
            if (name != null)
                artist_name.setText(name);
        }

        // prevent the soft keyboard from showing at startup
        artist_name.setInputType(0);


        //InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        //imm.hideSoftInputFromWindow(artist_name.getWindowToken(), InputMethodManager.RESULT_UNCHANGED_SHOWN);



        //artist_name.setFocusableInTouchMode(true);
        //artist_name.requestFocus();

        artist_name.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {  //Toast.makeText(getActivity(), "false " +artist_name.getText(), Toast.LENGTH_LONG).show();

                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
                SharedPreferences.Editor prefEditor = preferences.edit();
                prefEditor.putString("pref_artist", artist_name.getText().toString()); //**syntax error on tokens**
                prefEditor.commit();

                updateArtists();
                //artist_name.setInputType(0);
                return false;
            }
        });

        // instantiate our ArtistAdapter class
        mArtistadApter = new StreamerAdapter(getActivity(), R.layout.list_item_artist, artists);

        ListView lv = (ListView) rootView.findViewById(R.id.listview_artist);
        //lv.requestFocus();

        lv.setAdapter(mArtistadApter);


        //context = lv.getContext();
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                //parent,getItemAtPosition(position);
                StreamerArtist sa = (StreamerArtist) parent.getItemAtPosition(position);
                String text = sa.name;

//Log.d("my filter", text);
// Toast.makeText(getActivity(),text, Toast.LENGTH_LONG).show();
                Intent i = new Intent(getActivity(), DetailActivity.class);
                i.putExtra("artist", text);
                //i.putExtra(Intent.EXTRA_TEXT, text);


                startActivity(i);

            }
        });

        return rootView;
    }
/*
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        //super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
        //inflater.inflate(R.menu.menu_main, menu);


        //MenuInflater inflater = getMenuInflater();
        //inflater.inflate(R.menu.options_menu, menu);

        inflater.inflate(R.menu.menu_main, menu);

        // Locate MenuItem with ShareActionProvider
        //MenuItem item = menu.findItem(R.id.menu_item_share);

        // Fetch and store ShareActionProvider
        //mShareActionProvider = (ShareActionProvider) item.getActionProvider();

    }
*/
    protected void updateArtists() {

        //boolean metric = preferences.getBoolean("pref_metric", true);
        ArtisTlisttaSk task = new ArtisTlisttaSk();
        //if (metric)
        String n = artist_name.getText().toString();
        if (n != null && n.length() > 0) {

            //Toast.makeText(getActivity(), "Seaching Spotify", Toast.LENGTH_LONG).show();
            task.execute(n);
        }
        else
            artist_name.setInputType(InputType.TYPE_CLASS_TEXT);

    }

    @Override
    public void onStart() {
        super.onStart();
        updateArtists();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.search:
                // menu.add(...) --> how to get the menu instance?
                artist_name.setInputType(InputType.TYPE_CLASS_TEXT);
                artist_name.requestFocus();

                InputMethodManager imm = (InputMethodManager) getActivity()
                        .getSystemService(Context.INPUT_METHOD_SERVICE);

                if (imm != null) {
                    imm.showSoftInput(artist_name, 0);
                }                //task.execute("94043");
                //updateArtists();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public class ArtisTlisttaSk extends AsyncTask<String, String, List> {

        static final String myLOGFILTER = "ArtisTlisttaSk";

        //static final String myLOGFILTER = ArtisTlisttaSk.getClass().getSimpleName();
        public ArtisTlisttaSk() {
        }

        //protected String doInBackground(String... args) {}
        //protected String doInBackground(Object[] params) {
        protected List doInBackground(String... params) {
            String q = params[0].trim().replaceAll(" ", "%20");

//Log.d("Spotify params[0]: ", params[0]);
//Log.d("Spotify q: ", q);
            List<StreamerArtist> sl = new ArrayList<StreamerArtist>();

            SpotifyApi api = new SpotifyApi();
            if (api == null)
                return null;
            SpotifyService spotify = api.getService();
            if (spotify == null)
                return null;

            ArtistsPager results = spotify.searchArtists(q);
            List listOfArtists = results.artists.items;

            for (int i = 0; i < listOfArtists.size(); i++) {
                StreamerArtist sa = new StreamerArtist();
                Artist a = (Artist) listOfArtists.get(i);
                sa.name = a.name;
                sa.id = a.id;

                if (a.images != null) {
                    // find the image that is 54 in height
                    String url = null;
                    for (int j = 0; j < a.images.size(); j++) {
                        if (a.images.get(j).height <= 64)
                            url = a.images.get(j).url;
                    }
                    if (url != null) {
                        sa.thumbnail = null;
                        try {
                            URL aURL = new URL(url);
                            URLConnection conn =
                                    conn = aURL.openConnection();
                            conn.connect();

                            InputStream is = conn.getInputStream();
                            BufferedInputStream bis = new BufferedInputStream(is);
                            sa.thumbnail = BitmapFactory.decodeStream(bis);
                            bis.close();
                            is.close();
                        } catch (IOException e) {
                            // TO DO
                            Log.e("ArtistAdapter", "Error getting bitmap", e);
                        }

                    }

                }
                sl.add(sa);

                // limit the list to MAX_ARTISTS_TO_LIST
                if (i >= MAX_ARTISTS_TO_LIST)
                    break;
            }


            return sl;
        }

        //@Override
        protected void onPostExecute(List l) {
            mArtistadApter.clear();
            artist_name.setInputType(InputType.TYPE_CLASS_TEXT);
            //Log.d("lengthg ", "length: " + s.length);
            if (l == null || l.size() == 0) {
                Toast.makeText(getActivity(), "No artists were found to display.", Toast.LENGTH_LONG).show();
                return;
            }
            //mArtistadApter.addAll(s);
            mArtistadApter.addAll(l);
            //mArtistadApter.getView()
            //mArtistadApter.add(s);
            Log.d("myFilter", "Post Execute artisists " + l.size());
            if (l.size() >= 20)
                Toast.makeText(getActivity(), "Only showing first " + MAX_ARTISTS_TO_LIST + " artists that match the search.", Toast.LENGTH_LONG).show();
            super.onPostExecute(l);
        }

    }
}


//https://api.spotify.com/v1/search?type=artist&q=Beyonc
//https://api.spotify.com/v1/search?type=tracks&q=evis