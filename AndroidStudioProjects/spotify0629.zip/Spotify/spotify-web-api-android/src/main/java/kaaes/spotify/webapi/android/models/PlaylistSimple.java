package kaaes.spotify.webapi.android.models;

/**
 * <a href="https://developer.spotify.com/web-api/object-model/#playlist-object-simplified">Playlist object model (simplified)</a>
 */
public class PlaylistSimple extends PlaylistBase {
    public PlaylistTracksInformation tracks;
}
