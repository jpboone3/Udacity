/**
 * Copyright (C) 2015 Spotify AB
 */
package kaaes.spotify.webapi.android.models;

import java.util.List;

public class Category {
  public String href;
  public List<Image> icons;
  public String id;
  public String name;
}
