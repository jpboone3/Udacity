package kaaes.spotify.webapi.android.models;

import java.util.Map;

public class LinkedTrack {
    public Map<String, String> external_urls;
    public String href;
    public String id;
    public String type;
    public String uri;
}
