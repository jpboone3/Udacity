package kaaes.spotify.webapi.android.models;

public class SnapshotId {
    public String snapshot_id;
}
