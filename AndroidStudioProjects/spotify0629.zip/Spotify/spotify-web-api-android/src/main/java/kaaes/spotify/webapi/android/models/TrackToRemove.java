package kaaes.spotify.webapi.android.models;

public class TrackToRemove {
    public String uri;
}
