package kaaes.spotify.webapi.android.models;

import java.util.Map;

public class ArtistSimple {
    public Map<String, String> external_urls;
    public String href;
    public String id;
    public String name;
    public String type;
    public String uri;
}
