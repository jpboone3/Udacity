package kaaes.spotify.webapi.android.models;

public class PlaylistTracksInformation {
    public String href;
    public int total;
}
