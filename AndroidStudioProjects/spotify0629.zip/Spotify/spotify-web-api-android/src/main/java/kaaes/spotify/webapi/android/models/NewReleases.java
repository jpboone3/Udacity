package kaaes.spotify.webapi.android.models;

public class NewReleases {
    public Pager<AlbumSimple> albums;
}
