package kaaes.spotify.webapi.android.models;

public class PlaylistsPager {
    public Pager<PlaylistSimple> playlists;
}
