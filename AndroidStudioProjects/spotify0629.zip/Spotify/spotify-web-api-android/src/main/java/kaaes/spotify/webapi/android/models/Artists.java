package kaaes.spotify.webapi.android.models;

import java.util.List;

public class Artists {
    public List<Artist> artists;
}
