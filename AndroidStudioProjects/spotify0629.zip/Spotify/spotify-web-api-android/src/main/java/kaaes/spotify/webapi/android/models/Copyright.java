package kaaes.spotify.webapi.android.models;

/**
 * <a href="https://developer.spotify.com/web-api/object-model/#copyright-object">Copyright object model</a>
 */
public class Copyright {
    public String text;
    public String type;
}
