package kaaes.spotify.webapi.android.models;

/**
 * <a href="https://developer.spotify.com/web-api/object-model/#followers-object">Followers</a>
 */
public class Followers {
    public String href;
    public int total;
}
