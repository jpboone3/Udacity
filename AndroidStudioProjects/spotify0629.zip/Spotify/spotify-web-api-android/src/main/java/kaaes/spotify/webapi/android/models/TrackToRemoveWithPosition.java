package kaaes.spotify.webapi.android.models;

import java.util.List;

public class TrackToRemoveWithPosition {
    public String uri;
    public List<Integer> positions;
}
