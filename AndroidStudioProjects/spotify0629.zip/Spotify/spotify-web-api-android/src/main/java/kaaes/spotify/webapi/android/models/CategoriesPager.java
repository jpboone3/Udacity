/**
 * Copyright (C) 2015 Spotify AB
 */
package kaaes.spotify.webapi.android.models;

public class CategoriesPager {
    public Pager<Category> categories;
}
